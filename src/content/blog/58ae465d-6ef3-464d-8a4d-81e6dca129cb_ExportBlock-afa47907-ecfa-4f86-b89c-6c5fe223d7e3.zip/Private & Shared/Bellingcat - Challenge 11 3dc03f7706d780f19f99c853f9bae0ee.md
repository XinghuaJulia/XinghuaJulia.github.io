# Bellingcat - Challenge 11

![image.png](Bellingcat%20-%20Challenge%2011/image.png)

Car plate first things first. There is a blue little box with stars in it, likely EU.

- There is a circular blip in the middle of the car plate, which looking up the EU car plate website, indicates Germany
- http://www.worldlicenseplates.com/world/EU_EURO.html
- I mean, besides the german looking words and abundance of beer… yeah, it is Germany alright.

![image.png](Bellingcat%20-%20Challenge%2011/image%201.png)

SHISHAND- something, probably a beer place. Google maps shows that it is SHISHANDIS and there are only 2 stores in Frankfurt. Fantastic.

- **Stiftstraße**
- Found it!

Source: https://challenge.bellingcat.com/challenge/11